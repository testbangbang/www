
'use strict';


function onDisconnect(/*socket*/) {}


function onConnect(socket) {
  socket.on('info', data => {
    socket.log(JSON.stringify(data, null, 2));
  });

  socket.on('join', data => {
    socket.join(data.channel, () => {
      socket.broadcast.to(data.channel).emit('new user', data.content);
    });
  });

  socket.on('test_msg', function (data) {
    socket.emit('test_msg', data);
  })

}

var socketioHandle = function (socketio) {
  console.log('=================fff');
  socketio.on('connection', function(socket) {
    console.log('============= socket connection');
    socket.address = `${socket.request.connection.remoteAddress}:${socket.request.connection.remotePort}`;

    socket.connectedAt = new Date();

    socket.log = function(...data) {
      console.log(`SocketIO ${socket.nsp.name} [${socket.address}]`, ...data);
    };

    // Call onDisconnect.
    socket.on('disconnect', () => {
      onDisconnect(socket);
      socket.log('DISCONNECTED');
    });

    // Call onConnect.
    onConnect(socket);
    socket.log('CONNECTED');
  });
}

module.exports = socketioHandle;
